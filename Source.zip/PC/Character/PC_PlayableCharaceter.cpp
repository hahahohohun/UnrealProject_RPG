﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "PC_PlayableCharaceter.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Camera/CameraComponent.h"
#include "Component/PC_ActionComponent.h"
#include "Component/PC_AimComponent.h"
#include "Component/PC_BattleComponent.h"
#include "Component/PC_LockOnComponent.h"
#include "Component/PC_SkillComponent.h"
#include "Component/PC_StatComponent.h"
#include "Component/PC_WidgetComponent.h"
#include "Controller/PC_PlayerController.h"
//#include "Core/Tests/Containers/TestUtils.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Kismet/GameplayStatics.h"
#include "PC/Data/PC_InputDataAsset.h"
#include "PC/Data/PC_PlayerDataAsset.h"
#include "PC/Misc/GameMode/PCGameMode.h"
#include "PC/UI/PC_HUDWidget.h"
#include "PC/Utills/PC_GameUtill.h"
#include "Perception/AIPerceptionStimuliSourceComponent.h"
#include "Perception/AISense_Sight.h"


// Sets default values
APC_PlayableCharaceter::APC_PlayableCharaceter()
{
	// Create a camera boom (pulls in towards the player if there is a collision)
	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->SetupAttachment(RootComponent);
	CameraBoom->TargetArmLength = 600.0f; //데이터로 제어함	
	CameraBoom->bUsePawnControlRotation = true;
	
	// Create a follow camera
	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName); // Attach the camera to the end of the boom and let the boom adjust to match the controller orientation
	FollowCamera->bUsePawnControlRotation = false; // Camera does not rotate relative to arm

	StimulusSource = CreateDefaultSubobject<UAIPerceptionStimuliSourceComponent>(TEXT("Stimulus"));
	StimulusSource->RegisterForSense(TSubclassOf<UAISense>(UAISense_Sight::StaticClass()));
	StimulusSource->RegisterWithPerceptionSystem();

	WidgetComponent->SetRelativeLocation(FVector(0.0f, 0.0f, 200.0f));
	LockOnComponent = CreateDefaultSubobject<UPC_LockOnComponent>(TEXT("LockOnComponent"));
	
	ActionComponent = CreateDefaultSubobject<UPC_ActionComponent>(TEXT("ActionComponent"));
	AimComponent = CreateDefaultSubobject<UPC_AimComponent>(TEXT("AimComponent"));

	InteractionComponent = CreateDefaultSubobject<UPC_InteractionComponent>(TEXT("InteractionComponent"));
	InteractionOverlapComponent = CreateDefaultSubobject<USphereComponent>(TEXT("InteractionOverlapComponent"));
	InteractionOverlapComponent->SetupAttachment(RootComponent);
}

void APC_PlayableCharaceter::BeginPlay()
{
	Super::BeginPlay();

	//Add Input Mapping Context
	if (APlayerController* PlayerController = Cast<APlayerController>(Controller))
	{
		if (UEnhancedInputLocalPlayerSubsystem* Subsystem = ULocalPlayer::GetSubsystem<UEnhancedInputLocalPlayerSubsystem>(PlayerController->GetLocalPlayer()))
		{
			Subsystem->AddMappingContext(DefaultMappingContext, 0);
		}
	}

	if(!InteractionOverlapComponent->OnComponentBeginOverlap.IsAlreadyBound(InteractionComponent.Get(), &UPC_InteractionComponent::OnBeginOverlap))
		InteractionOverlapComponent->OnComponentBeginOverlap.AddDynamic(InteractionComponent.Get(), &UPC_InteractionComponent::OnBeginOverlap);

	if(!InteractionOverlapComponent->OnComponentEndOverlap.IsAlreadyBound(InteractionComponent.Get(), &UPC_InteractionComponent::OnEndOverlap))
		InteractionOverlapComponent->OnComponentEndOverlap.AddDynamic(InteractionComponent.Get(), &UPC_InteractionComponent::OnEndOverlap);
}

void APC_PlayableCharaceter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	
	UE_LOG(LogTemp, Log, TEXT(" SetupPlayerInputComponent"));
	
	// Set up action bindings
	if (UEnhancedInputComponent* EnhancedInputComponent = CastChecked<UEnhancedInputComponent>(PlayerInputComponent)) {
		
		EnhancedInputComponent->BindAction(InputData->JumpAction, ETriggerEvent::Triggered, this, &APC_PlayableCharaceter::Jump);
		EnhancedInputComponent->BindAction(InputData->JumpAction, ETriggerEvent::Completed, this, &ACharacter::StopJumping);
		EnhancedInputComponent->BindAction(InputData->MoveAction, ETriggerEvent::Triggered, this, &ThisClass::Move);
		EnhancedInputComponent->BindAction(InputData->LookAction, ETriggerEvent::Triggered, this, &ThisClass::Look);
		EnhancedInputComponent->BindAction(InputData->AttackAction, ETriggerEvent::Triggered, this, &ThisClass::Attack);

		EnhancedInputComponent->BindAction(InputData->SpecialAction, ETriggerEvent::Triggered, this, &ThisClass::SpecialAction);
		EnhancedInputComponent->BindAction(InputData->LockOnAction, ETriggerEvent::Triggered, this, &ThisClass::LockOn);
		EnhancedInputComponent->BindAction(InputData->BackstabOnAction, ETriggerEvent::Triggered, this, &ThisClass::Assassinate);
		
		EnhancedInputComponent->BindAction(InputData->RunAction, ETriggerEvent::Triggered, this, &ThisClass::Run);
		EnhancedInputComponent->BindAction(InputData->RollAction, ETriggerEvent::Triggered, this, &ThisClass::Roll);
		//
		EnhancedInputComponent->BindAction(InputData->WeaponSwapAction, ETriggerEvent::Triggered, this, &ThisClass::WeaponSwap);
		EnhancedInputComponent->BindAction(InputData->Num1Action, ETriggerEvent::Triggered, this, &ThisClass::Num1);
		EnhancedInputComponent->BindAction(InputData->Num2Action, ETriggerEvent::Triggered, this, &ThisClass::Num2);
		EnhancedInputComponent->BindAction(InputData->Num3Action, ETriggerEvent::Triggered, this, &ThisClass::Num3);
		EnhancedInputComponent->BindAction(InputData->Num4Action, ETriggerEvent::Triggered, this, &ThisClass::Num4);

		EnhancedInputComponent->BindAction(InputData->DebugDrawAction, ETriggerEvent::Triggered, this, &ThisClass::DebugDraw);

	}
}

void APC_PlayableCharaceter::Move(const FInputActionValue& Value)
{
	FVector2D Movement = Value.Get<FVector2D>();
	
	check(ActionComponent);
	ActionComponent->Move(Movement);
}

void APC_PlayableCharaceter::Jump(const FInputActionValue& Value)
{
	Super::Jump();
	const bool IsPressed = Value[0] != 0.f;
	
	check(ActionComponent);
	ActionComponent->Jump(IsPressed);
}

void APC_PlayableCharaceter::Look(const FInputActionValue& Value)
{
	// input is a Vector2D
	FVector2D LookAxisVector = Value.Get<FVector2D>();

	if (Controller != nullptr)
	{
		if(!LockOnComponent->IsLockOnMode())
		{
			// add yaw and pitch input to controller
			AddControllerYawInput(LookAxisVector.X);
			AddControllerPitchInput(LookAxisVector.Y);	
		}
	}
}


void APC_PlayableCharaceter::Attack(const FInputActionValue& Value)
{
	const bool IsPressed = Value[0] != 0.f;
	
	check(ActionComponent);
	check(BattleComponent)

	if(BattleComponent->CharacterStanceType == EPC_CharacterStanceType::Staff
		&& ActionComponent->IsInSpecialAction)
	{
		BattleComponent->FireProjectile(IsPressed);
	}
	else
	{
		ActionComponent->Attack(IsPressed);
	}
	
}


void APC_PlayableCharaceter::SpecialAction(const FInputActionValue& Value)
{
	const bool IsPressed = Value[0] != 0.f;

	check(ActionComponent);
	AdjustMovement(IsPressed);
	AdjustCamera(IsPressed);
	ActionComponent->SpecialAction(IsPressed);
}

void APC_PlayableCharaceter::Run(const FInputActionValue& Value)
{
	const bool IsPressed = Value[0] != 0.f;
	
	check(ActionComponent);
	ActionComponent->Run(IsPressed);
}

void APC_PlayableCharaceter::Roll(const FInputActionValue& Value)
{
	const bool IsPressed = Value[0] != 0.f;

	check(ActionComponent);
	ActionComponent->Roll(IsPressed);
}

void APC_PlayableCharaceter::WeaponSwap(const FInputActionValue& Value)
{
	const bool IsPressed = Value[0] != 0.f;

	check(ActionComponent);
	ActionComponent->SwapWeapon(IsPressed);
}


void APC_PlayableCharaceter::LockOn(const FInputActionValue& Value)
{
	const bool IsPressed = Value[0] != 0.f;
	if (!IsPressed)
		return;

	check(LockOnComponent);
	LockOnComponent->LockOn();
}

void APC_PlayableCharaceter::Assassinate(const FInputActionValue& Value)
{
	const bool IsPressed = Value[0] != 0.f;
	if (!IsPressed)
		return;
	
	//

	check(ActionComponent);
	ActionComponent->Assassinate(IsPressed);
}

void APC_PlayableCharaceter::Num1(const FInputActionValue& Value)
{
	const bool IsPressed = Value[0] != 0.f;
	if (!IsPressed)
		return;
	
	check(SkillComponent);
	check(BattleComponent);
	check(ActionComponent);
	
	const uint32 SkillId = FPC_GameUtil::GetSkillId(PlayerData,
		EPC_SkillSlotType::Num_1,
		BattleComponent->CharacterStanceType,
		ActionComponent->IsInSpecialAction);
	
	SkillComponent->RequestPlaySkill(SkillId);
}

void APC_PlayableCharaceter::Num2(const FInputActionValue& Value)
{	const bool IsPressed = Value[0] != 0.f;
	if (!IsPressed)
		return;
	
	check(SkillComponent);
	check(BattleComponent);
	check(ActionComponent);
	
	const uint32 SkillId = FPC_GameUtil::GetSkillId(PlayerData,
		EPC_SkillSlotType::Num_2,
		BattleComponent->CharacterStanceType,
		ActionComponent->IsInSpecialAction);
	
	SkillComponent->RequestPlaySkill(SkillId);
}

void APC_PlayableCharaceter::Num3(const FInputActionValue& Value)
{	const bool IsPressed = Value[0] != 0.f;
	if (!IsPressed)
		return;
	
	check(SkillComponent);
	check(BattleComponent);
	check(ActionComponent);
	
	const uint32 SkillId = FPC_GameUtil::GetSkillId(PlayerData,
		EPC_SkillSlotType::Num_3,
		BattleComponent->CharacterStanceType,
		ActionComponent->IsInSpecialAction);
	
	SkillComponent->RequestPlaySkill(SkillId);
}

void APC_PlayableCharaceter::Num4(const FInputActionValue& Value)
{	const bool IsPressed = Value[0] != 0.f;
	if (!IsPressed)
		return;
	
	check(SkillComponent);
	check(BattleComponent);
	check(ActionComponent);
	
	const uint32 SkillId = FPC_GameUtil::GetSkillId(PlayerData,
		EPC_SkillSlotType::Num_4,
		BattleComponent->CharacterStanceType,
		ActionComponent->IsInSpecialAction);
	
	SkillComponent->RequestPlaySkill(SkillId);
}

void APC_PlayableCharaceter::DebugDraw(const FInputActionValue& Value)
{
	const bool IsPressed = Value[0] != 0.0f;
	if(!IsPressed)
	{
		return;
	}

	UWorld* World = GetWorld();
	check(World);

	APCGameMode* GameMode = Cast<APCGameMode>(World->GetAuthGameMode());
	check(GameMode);

	GameMode->DebugDrawing = !GameMode->DebugDrawing;
}

void APC_PlayableCharaceter::OnSensedByBossMonster(ACharacter* Incharacter) const
{
	OnEnCounterBossMonsterDelegate.Broadcast(Incharacter);
}

void APC_PlayableCharaceter::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);

	if (NewController->GetClass() == APC_PlayerController::StaticClass())
		SetGenericTeamId(FGenericTeamId(0));
}

void APC_PlayableCharaceter::SetupHUDWidget(UPC_HUDWidget* InWidget)
{
	if (InWidget)
	{
		InWidget->UpdateStat(StatComponent->GetBaseStat(), StatComponent->GetModifierStat());
		InWidget->SetOwningActor(this);
		
		StatComponent->OnStatChangedDelegate.AddUObject(InWidget, &UPC_HUDWidget::UpdateStat);
		
		StatComponent->OnHPChangedDelegate.AddUObject(InWidget, &UPC_HUDWidget::UpdateHPBar);
		StatComponent->OnMPChangedDelegate.AddUObject(InWidget, &UPC_HUDWidget::UpdateMPBar);
		StatComponent->OnStaminaChangedDelegate.AddUObject(InWidget, &UPC_HUDWidget::UpdateStaminaBar);

		OnEnCounterBossMonsterDelegate.AddUObject(InWidget, &UPC_HUDWidget::OnEnCounterBossMonster);
	}
}

void APC_PlayableCharaceter::ReactAttackBreak()
{
	
}

//bOrientRotationToMovement : true 가속을 받는 방향으로 캐릭터가 회전
void APC_PlayableCharaceter::AdjustMovement(bool IsPressed)
{
	if (IsPressed && !ActionComponent->IsInSpecialAction)
	{
		GetCharacterMovement()->MaxWalkSpeed = PlayerData->MovementSpeed_Walk;
		GetCharacterMovement()->bOrientRotationToMovement = false;
	}
	else if (!IsPressed && ActionComponent->IsInSpecialAction)
	{
		GetCharacterMovement()->MaxWalkSpeed = PlayerData->MovementSpeed_Jog;
		GetCharacterMovement()->bOrientRotationToMovement = true;
	}
}

void APC_PlayableCharaceter::AdjustCamera(bool bIsPressed)
{
	if (bIsPressed && !ActionComponent->IsInSpecialAction)
	{
		if (BattleComponent->CharacterStanceType == EPC_CharacterStanceType::Staff && AimComponent->CurrentCameraType != EPC_CameraType::Aim)
		{
			AimComponent->SwitchCamera(EPC_CameraType::Aim);
		}
	}
	else if (!bIsPressed && ActionComponent->IsInSpecialAction)
	{
		if (BattleComponent->CharacterStanceType == EPC_CharacterStanceType::Staff && AimComponent->CurrentCameraType != EPC_CameraType::Normal)
		{
			AimComponent->SwitchCamera(EPC_CameraType::Normal);
		}
	}
}

void APC_PlayableCharaceter::SetGenericTeamId(const FGenericTeamId& TeamID)
{
	GenericTeamId = TeamID;
}

FGenericTeamId APC_PlayableCharaceter::GetGenericTeamId() const
{
	return GenericTeamId;
}